export interface IWaterQuality {
    id?: number | null | undefined;
    tss: number | null | undefined;
    cl: number | null | undefined;
    ph: number | null | undefined;
    cod: number | null | undefined;
    tp: number | null | undefined;
  }
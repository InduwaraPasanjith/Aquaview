export interface IPlant {
    id?: number | null | undefined;
    name:string;
    address: string;
  }
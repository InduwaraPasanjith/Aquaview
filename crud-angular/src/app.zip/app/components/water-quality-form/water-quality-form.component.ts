import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { HttpService } from '../../http.service';
import { IEmployee } from '../../interfaces/employee';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IWaterQuality } from '../../interfaces/waterQuality';

@Component({
  selector: 'app-water-quality-form',
  standalone: true,
  imports: [MatInputModule, MatButtonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './water-quality-form.component.html',
  styleUrl: './water-quality-form.component.css'
})
export class WaterQualityFormComponent {
  formBuilder = inject(FormBuilder);
  httpService = inject(HttpService);
  router = inject(Router);
  route = inject(ActivatedRoute);
  toaster=inject(ToastrService);

  employeeForm = this.formBuilder.group({
    tss: [0, [Validators.required]],
    cl: [0, [Validators.required]],
    ph: [0, [Validators.required]],
    cod: [0, []],
    tp: [0, [Validators.required]],
  });

//  constructor(private http: HttpClient) {}

  save() {
    console.log(this.employeeForm.value);
    const employee: IWaterQuality = {
      tss: this.employeeForm.value.tss,
      cl: this.employeeForm.value.cl,
      ph: this.employeeForm.value.ph,
      cod: this.employeeForm.value.cod,
      tp: this.employeeForm.value.tp,
    };
    
      this.httpService.checkWaterQuality(employee).subscribe(() => {
        console.log('success');
        this.toaster.success("Record added sucessfully.");
        this.router.navigateByUrl('/employee-list');
      });
    
  }
}
